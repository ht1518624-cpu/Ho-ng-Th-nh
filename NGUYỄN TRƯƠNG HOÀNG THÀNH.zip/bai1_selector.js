$(document).ready(function () {
    // 1. Ẩn hiện các block (div, p, h1,...)
    $("#btnToggleBlock").click(function () {
        $("#block-demo, #block-demo p, #block-demo h1").toggle(300);
    });

    // 2. Tìm tất cả các thẻ <input type="checkbox"> và hiển thị giá trị đang chọn (checked)
    $("#btnCheck").click(function () {
        let selected = [];
        $('input[type="checkbox"]:checked').each(function () {
            selected.push($(this).val());
        });
        $("#ketQuaCheckbox").text("Đang chọn: " + (selected.length ? selected.join(", ") : "Không có"));
    });

    // 3. Tìm tất cả các thẻ <option> của thẻ <select id="country">
    $("#btnOption").click(function () {
        let options = $("#country option");
        let list = [];
        options.each(function () {
            list.push($(this).text() + " (" + $(this).val() + ")");
        });
        alert("Tổng số option: " + options.length + "\nDanh sách: " + list.join(", "));
    });

    // 4. Tìm các thẻ <img> đặt trong <div id="menu">
    $("#btnImg").click(function () {
        $("#menu img").css({
            "border": "3px solid green",
            "border-radius": "8px",
            "margin-right": "10px"
        });
    });

    // 5. Tìm tất cả các thẻ <input type="text"> chưa nhập dữ liệu -> gắn class error
    $("#btnValidateText").click(function () {
        $('input[type="text"]').each(function () {
            if ($(this).val().trim() === "") {
                $(this).addClass("error");
            } else {
                $(this).removeClass("error");
            }
        });
    });

    // 6. Thay đổi kiểu dáng các thành phần web (màu nền hàng bảng, đường kẻ vùng, thông báo)
    $("#btnStyle").click(function () {
        // Màu nền hàng chẵn/lẻ và hiệu ứng hover
        $("#tblDemo tr:even").css("background-color", "#e9ecef");
        $("#tblDemo tr:odd").css("background-color", "#ffffff");
        $("#tblDemo tr").hover(
            function () { $(this).css("background-color", "#ffeeba"); },
            function () { $(this).css("background-color", ""); }
        );

        // Đường kẻ và nền cho các vùng .box
        $(".box").addClass("highlight-bg");
    });
});
