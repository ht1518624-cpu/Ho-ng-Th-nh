$(document).ready(function () {
    let isLoggedIn = false;

    $("#btnAuth").click(function () {
        if (!isLoggedIn) {
            let user = $("#username").val().trim();
            let pass = $("#password").val().trim();

            // Kiểm tra tài khoản mẫu: admin / admin
            if (user === "admin" && pass === "admin") {
                isLoggedIn = true;
                $("#thongBao").text("Chúc mừng, bạn đã đăng nhập thành công!").css("color", "green");

                // Nâng cao: Thay nút Login thành Logout
                $(this).text("Logout");

                // Nâng cao: Ẩn thẻ input nhập liệu và thêm thẻ div hiển thị nội dung tương ứng
                $("#username").hide();
                $("#userDisplay").text(user).show();

                $("#password").hide();
                $("#passDisplay").text(pass).show();
            } else {
                $("#thongBao").text("Sai thông tin đăng nhập !").css("color", "red");
            }
        } else {
            // Xử lý khi bấm Logout để quay lại trạng thái ban đầu
            isLoggedIn = false;
            $(this).text("Login");
            $("#username").val("").show();
            $("#password").val("").show();
            $("#userDisplay, #passDisplay").hide().text("");
            $("#thongBao").html("&nbsp;");
        }
    });
});
