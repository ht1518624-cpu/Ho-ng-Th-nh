$(document).ready(function () {
    const rows = 10;
    const cols = 10;
    let currentPlayer = "X";

    // Tạo bàn cờ 10x10 và định dạng dòng chẵn lẻ màu khác nhau
    const $board = $("#caroBoard");
    for (let r = 0; r < rows; r++) {
        let $tr = $("<tr></tr>");
        // Định dạng các dòng chẵn lẻ màu sắc khác nhau
        $tr.addClass(r % 2 === 0 ? "row-even" : "row-odd");

        for (let c = 0; c < cols; c++) {
            $tr.append("<td></td>");
        }
        $board.append($tr);
    }

    // Đánh X, O xen kẽ khi click vào ô trống
    $("#caroBoard").on("click", "td", function () {
        if ($(this).text() === "") {
            $(this).text(currentPlayer);
            $(this).css("color", currentPlayer === "X" ? "#d9534f" : "#0275d8");
            currentPlayer = (currentPlayer === "X") ? "O" : "X";
        }
    });

    // Các hiệu ứng: xuất hiện, biến mất, toggle
    $("#btnHide").click(function () {
        $("#caroBoard").hide(400);
    });

    $("#btnShow").click(function () {
        $("#caroBoard").show(400);
    });

    $("#btnToggle").click(function () {
        $("#caroBoard").toggle(400);
    });
});
