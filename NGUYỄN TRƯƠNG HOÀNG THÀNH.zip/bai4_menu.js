$(document).ready(function () {
    // Cho tất cả các menu nhóm ẩn đi lúc ban đầu
    $(".menu_nhom").hide();

    // Gán sự kiện click lên menu thể loại thì hiển thị/ẩn menu nhóm ngay sau nó
    $(".menu_theloai").click(function () {
        $(this).next(".menu_nhom").slideToggle(300);
    });
});
