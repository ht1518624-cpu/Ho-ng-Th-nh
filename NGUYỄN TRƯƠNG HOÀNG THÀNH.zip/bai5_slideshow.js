$(document).ready(function () {
    var i = 10;

    $("#btnLeft").click(function () {
        // Giới hạn không trượt quá xa sang trái
        if (i > -240) {
            i -= 250;
            $(".slideshow_inner").animate({
                marginLeft: i
            }, 500);
        }
    });

    $("#btnRight").click(function () {
        // Giới hạn không trượt quá vị trí ban đầu
        if (i < 10) {
            i += 250;
            $(".slideshow_inner").animate({
                marginLeft: i
            }, 500);
        }
    });
});
